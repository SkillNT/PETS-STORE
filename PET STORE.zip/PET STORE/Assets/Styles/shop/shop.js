// NEXT & BACK BUTTONS
document.getElementById("prevBtn").addEventListener("click", function() {
    document.getElementById("item-list-1").scrollBy({
        left:-220, behavior: 'smooth'});
        console.log("NEXT");
        
    });

    document.getElementById("nextBtn").addEventListener("click", function() {
        document.getElementById("item-list-1").scrollBy({
            left:220, behavior: 'smooth'});
            console.log("Prev");
            
        });


        //ITEM LIST 2
document.getElementById("prevBtn2").addEventListener("click", function() {
    document.getElementById("item-list-2").scrollBy({
        left:-220, behavior: 'smooth'});
        console.log("NEXT 2");
        
    });

    document.getElementById("nextBtn2").addEventListener("click", function() {
        document.getElementById("item-list-2").scrollBy({
            left:220, behavior: 'smooth'});
            console.log("Prev 2");
            
        });

        // BUY
        let buy = document.getElementById("buy-item-e");
        let not = document.getElementById("not");

        function buyItem() {
            not.display = "block";
            console.log("Order");
            
        }
        buy.addEventListener("click", buyItem);