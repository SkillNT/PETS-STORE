let sidebar = document.getElementById("sidebar");
let sideBtn = document.getElementById("sideButton");

sideBtn.addEventListener("click", function() {
    sidebar.classList.toggle('active');
    console.log("Clicked Sidebar");
    
});


//SIDE LINKS

// HOME
let homeBtn  = document.getElementById("homeBtn");

function homePage() {
    const anchor = document.createElement("a");
    anchor.target = "_parent";
    anchor.href = "../home.html";
    document.body.appendChild(anchor);
    anchor.click();

    console.log("Home Pages (sidebar)");
};

homeBtn.addEventListener("click", homePage);



let aboutBtn  = document.getElementById("aboutBtn");

aboutBtn.addEventListener("click", function(){

    const anchor1 = document.createElement("a");
    anchor1.target = "_parent";
    anchor1.href = "../Pages/about.html";
    document.body.appendChild(anchor1);
    anchor1.click();

    console.log("Home Pages (sidebar)");
});
