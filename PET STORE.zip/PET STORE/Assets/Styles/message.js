let messageBox  = document.getElementById("message-box");
let backBtn = document.getElementById("backBtn");
let messageBtn = document.getElementById("MessageBtn");

function fixedMessage() {
    messageBox.classList.toggle('active');
    console.log("Clicked Send Message !");
};

messageBtn.addEventListener("click", fixedMessage);
backBtn.addEventListener("click", fixedMessage);
